<?php 
class Qr_code
{
  public $server = "localhost";
  public $user = "root";
  public $pass = "";
  public $dbname = "qr_code";
	public $conn;

  public function __construct()
  {
  	$this->conn = new mysqli($this->server,$this->user,$this->pass,$this->dbname);
  	if($this->conn->connect_error)
  	{
  		die("connection failed");
  	}
  }
 	public function insertQr($qrUname,$qc,$qrimage)
 	{
 			$sql = "INSERT INTO tbqrcode(QrUsername,QrContent,QrImg) VALUES('$qrUname','$qc','$qrimage')";
 			$query = $this->conn->query($sql);
 			return $query;
 	}
 	
}
$vibqr = new Qr_code();