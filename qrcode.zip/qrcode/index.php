
<!DOCTYPE html>
<html>
<head>
  <title>Qr generator by Fahma</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">

<style>
body {font-family: Arial, Helvetica, sans-serif;
background-color: grey;}

input[type=text]{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}


input[type=submit]{
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    text-align: center;
    text-decoration: none;

}

input[type=submit]:hover {
    opacity: 0.8;
}




.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}


.modal {
    
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    padding-top: 60px;
}
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; 
    border: 1px solid #888;
    width: 80%; 
}
.animate {
    animation: animatezoom 0.6s
}
@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
#qrSucc
{
  width: 90%;
  margin:  auto;
  text-align: center;
}
#qrSucc a
{
    
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    text-align: center;
    text-decoration: none;
}
#download
{
	background-color: blue;
}
#again
{
	background-color: green;
}
</style>
</head>
<body>
    <?php 
  		include 'phpqrcode/qrlib.php';
 		include 'config.php';
  		if(isset($_POST['create']))
  		{
    		$qc =  $_POST['qrContent'];
    		$qrUname = $_POST['qrUname'];
    		
    		$qrImgName = 'QrVib'.rand();

    		if($qc=="" && $qrUname=="")
    		{
      			echo "<script>alert('Please Enter Your Name And Text/Link For QR Code');</script>";
    		}
    		elseif($qc=="")
    		{
      		echo "<script>alert('Please Enter Text/Link For QR Code');</script>";
    		}
    		elseif($qrUname=="")
    		{
      		echo "<script>alert('Please Enter Your Name');</script>";
    		}
    		else
    		{
    			$qrs = QRcode::png($qc,"Qrcodes/$qrImgName.png","H","3","3");
    			$qrimage = $qrImgName.".png";
    			$insQr = $vibqr->insertQr($qrUname,$qc,$qrimage);
    			if($insQr == true)
    			{
      				echo "<script>alert('Thank You $qrUname. Successfully Created Your QR Code!'); window.location='index.php?success=$qrimage';</script>";
    			}
    			else
    			{
      				echo "<script>alert('can't create QR Code');</script>";
    			}
  			}
 		}
  	?>

  	<?php 
  		if(isset($_GET['success']))
  		{
  	?>
  			<div id="qrSucc">
  				<div class="modal-content animate container">
    				<img src="QrCodes/<?php echo $_GET['success']; ?>" alt="">
    				<br>
     				<br><br>
					<a id="download" href="download.php?download=<?php echo $_GET['success']; ?>">Download</a>
					<br>
 					<br><br>
    				<a id="again" href="index.php">Go Back To Generate Again</a>
     			</div>
     		</div>
  	<?php
		}
		else
		{
  	?>
			<div id="id01" class="modal">
  				<form class="modal-content animate" method="post" enctype="multipart/form-data">
    				<div class="container">
      					<h2 align="center">QR Code Generator</h2>
      					<label for="uname"><b>Your Name</b></label>
      					<input type="text" name="qrUname" value="<?php if(isset($_POST['create'])){ echo $_POST['qrUname']; } ?>">
      					<label for="content"><b>  Text/Link For QR Code</b></label>
      					<input type="text" name="qrContent" value="<?php if(isset($_POST['create'])){ echo $_POST['qrContent']; } ?>">   
      					<input type="submit" value="Generate QR Code" name="create">
    				</div>
  				</form>
  			</div>
	<?php 
	}
	?>
</body>
</html>