<?php 
if(isset($_GET['download']))
{
$file_name = $_GET['download'];

$filepath = 'QrCodes/'.$file_name;
header('Content-Type: application/octet-stream');
header("Content-Encoding: none"); 
header("Content-Disposition: attachment; filename=$file_name"); 
readfile($filepath);
}
?>